import React from 'react'

const LoaderComp = () => {
    return (
        <>
            <section className="loder-sec d-flex justify-content-center align-items-center">
                <div className="lds-spinner"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
            </section>

        </>
    )
}

export default LoaderComp