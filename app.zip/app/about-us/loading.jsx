import React from 'react'
import LoaderComp from '../components/LoaderComp/LoaderComp'

const HomeLoading = () => {
  return (
    <>
    <LoaderComp/>
    </>
  )
}

export default HomeLoading