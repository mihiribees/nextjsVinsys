const TokenMessage = ()=>{   
   alert("clicked")
   return(
    <p>hello</p>
   )
    
}
export default TokenMessage;