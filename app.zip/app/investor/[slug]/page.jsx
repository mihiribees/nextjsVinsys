import React from 'react'

const InvestorPageDetails = () => {
  return (
    <div>InvestorPageDetails</div>
  )
}

export default InvestorPageDetails