export default function TrainingCertification() {
  return <>
  <>Training Home PAge</>
  </>;
}
