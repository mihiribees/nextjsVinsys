export default function GovernmentTraining() {
  return <>
  <>GovernmentTraining PAge</>
  </>;
}
