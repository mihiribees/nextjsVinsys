export default function GuranteeRunClassPage() {
  return <>
  <>GuranteeRunClassPage PAge</>
  </>;
}
