export default function GetObligationPage() {
  return <>
  <>GetObligationPage PAge</>
  </>;
}
