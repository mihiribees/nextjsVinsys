export default function CourseDetails() {
  return <>
  <>CourseDetails PAge</>
  </>;
}
