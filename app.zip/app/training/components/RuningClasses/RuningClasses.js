// import OnlineOnlineIcon from '../../image/online.svg';
// import OnlineClassroomIcon from '../../image/classroom.svg';
// import CommonBtn from '../../other/Headingtext-Btn';
const RuningClass = ({topfilterneed,serachresult,recomended,searchboxneed})=>{
    return(
        <>
        </>
        // <section className="guarantee-runclass-sec common-spacing-top-bottom">
        //     <div className="inner-container">
        //         <div className={`top-filters ${topfilterneed}`}>
        //             <ul className="common-from d-flex">
        //                 <li className="date-range">
        //                     <label>Date Range</label>
        //                     <div className="start-end-date d-flex">
        //                         <input type="date" placeholder="Start Date" id="s-date" name="s-date" />
        //                         <input type="date" placeholder="End Date" id="e-date" name="e-date" />
        //                     </div>
        //                 </li>
        //                 <li>
        //                     <label>Language:</label>
        //                     <select name="lang" id="language" form="">
        //                         <option value="all">All</option>
        //                         <option value="english">English</option>
        //                     </select>
        //                 </li>

        //                 <li>
        //                     <label>Location:</label>
        //                     <select name="location" id="location" form="">
        //                         <option value="all">All</option>
        //                         <option value="india">India</option>
        //                     </select>
        //                 </li>

        //                 <li>
        //                     <label>Brand:</label>
        //                     <select name="brand" id="brand" form="">
        //                         <option value="all">All</option>
        //                         <option value="Microsoft">Microsoft</option>
        //                     </select>
        //                 </li>

        //                 <li>
        //                     <label>Domain:</label>
        //                     <select name="domain" id="domain" form="">
        //                         <option value="all">All</option>
        //                         <option value="xyz">xyz</option>
        //                     </select>
        //                 </li>                        
        //                 <li className="checkboxs-btn d-flex">
        //                     <div className="checkbox-wrapper d-flex">
        //                         <div className="checkbox d-flex align-items-center">
        //                             <input type="checkbox" id="online" name="online" value="online" />
        //                             <label for="online"><img src={OnlineOnlineIcon} alt="" /> Online</label>
        //                         </div>
        //                         <div className="checkbox d-flex align-items-center">
        //                             <input type="checkbox" id="classroom" name="classroom" value="classroom" />
        //                             <label for="classroom"><img src={OnlineClassroomIcon} alt="" /> Classroom</label>
        //                         </div>
        //                     </div>
        //                     <div className="btn-wrapper">
        //                         <button type="submit" className="common-btn">Apply Filter <i className="icon">&nbsp;</i></button>
        //                     </div>
        //                 </li>
        //             </ul>
        //         </div>

        //         <div className="items mt-60">
        //             <div className="searchfilter d-flex align-items-center">
        //                 <div className={`search-result ${serachresult}`}>1987 Courses Found</div>
        //                 <div className={`search-result ${recomended}`}>Recomended Courses For You</div>
        //                 <div className={`searchbox common-from ${searchboxneed}`}>
        //                     <input type="text" placeholder="Search Courses" />
        //                 </div>
        //             </div>
        //             <div className="item d-flex justify-content-between">
        //                 <div className="left-section d-flex align-items-start">                            
        //                     <div className="content-box">
        //                         <div className="top-wrapper d-flex">
        //                             <div className="detail">
        //                                 <div className="course-name">Administering a SQL Database (55316)<span><strong>Delivery format :</strong> Virtual Classroom Live</span></div>
        //                                 <div className="date-time-wraper d-flex align-items-center">
        //                                     <div className="date">
        //                                         <span>Date</span>June 08 - 12 , 2023
        //                                     </div>
        //                                     <div className="time">
        //                                         <span>Time</span>10:00 AM - 4:00 PM EDT
        //                                     </div>
        //                                 </div>
        //                                 <div className="duration-detail-wrapper d-flex align-items-center justify-content-between">
        //                                     <div className="duration">Duration : <span>1 Month</span></div>
        //                                     <a href="#" className="common-btn light-bg short">View Details</a>
        //                                 </div>
        //                             </div>
        //                             <div className="qty-price">
        //                                 <form action="">
        //                                     <div className="qty-box">
        //                                         <select name="lang" id="language" form="">
        //                                             <option value="1">Qty: 1</option>
        //                                             <option value="2">Qty: 2</option>
        //                                         </select>
        //                                     </div>
        //                                     <div className="price">Price : <span>$399</span></div>
        //                                 </form>
        //                             </div>
                                    
        //                         </div>                                
                                
        //                     </div>
        //                 </div>
        //                 <div className="right-section">
        //                     <div className="btn-wrapper">
        //                         <CommonBtn class="" link="" text="Add To Cart"/>
        //                         <CommonBtn class="light-bg short no-icon" link="" text="Generate a Quote"/>  
        //                     </div>
        //                 </div>
        //             </div>   
        //             <div className="item d-flex justify-content-between">
        //                 <div className="left-section d-flex align-items-start">                            
        //                     <div className="content-box">
        //                         <div className="top-wrapper d-flex">
        //                             <div className="detail">
        //                                 <div className="course-name">Administering a SQL Database (55316)<span><strong>Delivery format :</strong> Virtual Classroom Live</span></div>
        //                                 <div className="date-time-wraper d-flex align-items-center">
        //                                     <div className="date">
        //                                         <span>Date</span>June 08 - 12 , 2023
        //                                     </div>
        //                                     <div className="time">
        //                                         <span>Time</span>10:00 AM - 4:00 PM EDT
        //                                     </div>
        //                                 </div>
        //                                 <div className="duration-detail-wrapper d-flex align-items-center justify-content-between">
        //                                     <div className="duration">Duration : <span>1 Month</span></div>
        //                                     <a href="#" className="common-btn light-bg short">View Details</a>
        //                                 </div>
        //                             </div>
        //                             <div className="qty-price">
        //                                 <form action="">
        //                                     <div className="qty-box">
        //                                         <select name="lang" id="language" form="">
        //                                             <option value="1">Qty: 1</option>
        //                                             <option value="2">Qty: 2</option>
        //                                         </select>
        //                                     </div>
        //                                     <div className="price">Price : <span>$399</span></div>
        //                                 </form>
        //                             </div>
                                    
        //                         </div>                                
                                
        //                     </div>
        //                 </div>
        //                 <div className="right-section">
        //                     <div className="btn-wrapper">
        //                         <CommonBtn class="" link="" text="Add To Cart"/>
        //                         <CommonBtn class="light-bg short no-icon" link="" text="Generate a Quote"/>                                
        //                     </div>
        //                 </div>
        //             </div>    
        //             <div className="item d-flex justify-content-between">
        //                 <div className="left-section d-flex align-items-start">                            
        //                     <div className="content-box">
        //                         <div className="top-wrapper d-flex">
        //                             <div className="detail">
        //                                 <div className="course-name">Administering a SQL Database (55316)<span><strong>Delivery format :</strong> Virtual Classroom Live</span></div>
        //                                 <div className="date-time-wraper d-flex align-items-center">
        //                                     <div className="date">
        //                                         <span>Date</span>June 08 - 12 , 2023
        //                                     </div>
        //                                     <div className="time">
        //                                         <span>Time</span>10:00 AM - 4:00 PM EDT
        //                                     </div>
        //                                 </div>
        //                                 <div className="duration-detail-wrapper d-flex align-items-center justify-content-between">
        //                                     <div className="duration">Duration : <span>1 Month</span></div>
        //                                     <a href="#" className="common-btn light-bg short">View Details</a>
        //                                 </div>
        //                             </div>
        //                             <div className="qty-price">
        //                                 <form action="">
        //                                     <div className="qty-box">
        //                                         <select name="lang" id="language" form="">
        //                                             <option value="1">Qty: 1</option>
        //                                             <option value="2">Qty: 2</option>
        //                                         </select>
        //                                     </div>
        //                                     <div className="price">Price : <span>$399</span></div>
        //                                 </form>
        //                             </div>
                                    
        //                         </div>                                
                                
        //                     </div>
        //                 </div>
        //                 <div className="right-section">
        //                     <div className="btn-wrapper">
        //                         <CommonBtn class="" link="" text="Add To Cart"/>
        //                         <CommonBtn class="light-bg short no-icon" link="" text="Generate a Quote"/>  
        //                     </div>
        //                 </div>
        //             </div>    
        //             <div className="item d-flex justify-content-between">
        //                 <div className="left-section d-flex align-items-start">                            
        //                     <div className="content-box">
        //                         <div className="top-wrapper d-flex">
        //                             <div className="detail">
        //                                 <div className="course-name">Administering a SQL Database (55316)<span><strong>Delivery format :</strong> Virtual Classroom Live</span></div>
        //                                 <div className="date-time-wraper d-flex align-items-center">
        //                                     <div className="date">
        //                                         <span>Date</span>June 08 - 12 , 2023
        //                                     </div>
        //                                     <div className="time">
        //                                         <span>Time</span>10:00 AM - 4:00 PM EDT
        //                                     </div>
        //                                 </div>
        //                                 <div className="duration-detail-wrapper d-flex align-items-center justify-content-between">
        //                                     <div className="duration">Duration : <span>1 Month</span></div>
        //                                     <a href="#" className="common-btn light-bg short">View Details</a>
        //                                 </div>
        //                             </div>
        //                             <div className="qty-price">
        //                                 <form action="">
        //                                     <div className="qty-box">
        //                                         <select name="lang" id="language" form="">
        //                                             <option value="1">Qty: 1</option>
        //                                             <option value="2">Qty: 2</option>
        //                                         </select>
        //                                     </div>
        //                                     <div className="price">Price : <span>$399</span></div>
        //                                 </form>
        //                             </div>
                                    
        //                         </div>                                
                                
        //                     </div>
        //                 </div>
        //                 <div className="right-section">
        //                     <div className="btn-wrapper">
        //                         <CommonBtn class="" link="" text="Add To Cart"/>
        //                         <CommonBtn class="light-bg short no-icon" link="" text="Generate a Quote"/>  
        //                     </div>
        //                 </div>
        //             </div>                    
                    
        //         </div>
        //     </div>
        // </section>
    )
}
export default RuningClass;