import CommonBtn, { CommonHeading } from "../../other/Headingtext-Btn";
const TrainingSolution = () => {
    return (
        <section className="needHelpSection  common-spacing-top-bottom">
            <div className="inner-container">
                <CommonHeading class="text-center" mainHeading="Need Help Finding The Right Training Solution"/>
                <p>Our Training Advisors Are Here For You</p>
                <CommonBtn link="" text="Contact Us"/>
            </div>
        </section>
    )
}

export default TrainingSolution;