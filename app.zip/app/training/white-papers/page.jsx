export default function WhitePaperPage() {
  return <>
  <>WhitePaperPage PAge</>
  </>;
}
