export default function DeliveryMode() {
  return <>
  <>DeliveryMode PAge</>
  </>;
}
