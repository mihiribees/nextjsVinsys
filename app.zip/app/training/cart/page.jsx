export default function CartPage() {
  return <>
  <>CartPage</>
  </>;
}
