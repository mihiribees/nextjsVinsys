export default function PromotionPage() {
  return <>
  <>PromotionPage PAge</>
  </>;
}
