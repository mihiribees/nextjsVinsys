export default function CreateAccountPage() {
  return <>
  <>CreateAccountPage PAge</>
  </>;
}
