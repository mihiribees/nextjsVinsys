import React from 'react'

const Trainingloading = () => {
  return (
    <div>Trainingloading</div>
  )
}

export default Trainingloading