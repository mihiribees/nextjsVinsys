export default function Webinars() {
  return <>
  <>Webinars PAge</>
  </>;
}
