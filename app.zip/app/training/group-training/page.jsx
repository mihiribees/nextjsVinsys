export default function GroupTrainingPage() {
  return <>
  <>GroupTrainingPage PAge</>
  </>;
}
