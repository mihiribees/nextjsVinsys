export default function CaseStudyPage() {
  return (
    <>
      <>CaseStudyPage</>
    </>
  );
}
