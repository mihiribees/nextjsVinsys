export default function ForgotPassword() {
  return <>
  <>ForgotPassword  PAge</>
  </>;
}
