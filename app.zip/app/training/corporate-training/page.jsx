export default function CarporateTraining() {
  return <>
  <>CarporateTraining</>
  </>;
}
