export default function GenrateQuote() {
  return <>
  <>GenrateQuote Page</>
  </>;
}
