export default function IndiviualTrainingPage() {
  return <>
  <>IndiviualTrainingPage PAge</>
  </>;
}
