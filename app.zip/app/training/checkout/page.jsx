export default function CheckOutPage() {
  return <>
  <>Training Home PAge</>
  </>;
}
