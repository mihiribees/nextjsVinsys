import LoaderComp from '@/app/components/LoaderComp/LoaderComp'
import React from 'react'

const HomeLoading = () => {
  return (
   <>
   <LoaderComp/>
   
   </>
  )
}

export default HomeLoading