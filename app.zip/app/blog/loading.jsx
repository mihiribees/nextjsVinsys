import React from 'react'

const HomeLoading = () => {
  return (
    <div>Loading...</div>
  )
}

export default HomeLoading