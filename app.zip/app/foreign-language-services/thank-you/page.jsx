import React from 'react'

const ThankYou = () => {
  return (
    <div>ThankYou</div>
  )
}

export default ThankYou