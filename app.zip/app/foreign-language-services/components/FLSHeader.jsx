import React from 'react'

const FLSHeader = () => {
  return (
    <div>FLSHeader</div>
  )
}

export default FLSHeader