"use client"
import React from 'react'

const FLSIndustriesPage = () => {
  return (
    <div>FLSIndustriesPage</div>
  )
}

export default FLSIndustriesPage