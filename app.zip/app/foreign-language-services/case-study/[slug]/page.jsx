import React from 'react'

const CaseStudyDetailsPage = () => {
  return (
    <div>CaseStudyDetailsPage</div>
  )
}

export default CaseStudyDetailsPage