import React from 'react'

const ResourcePage = () => {
  return (
    <div>ResourcePage</div>
  )
}

export default ResourcePage