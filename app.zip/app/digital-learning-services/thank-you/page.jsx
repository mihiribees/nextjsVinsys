import React from 'react'

const ThankYouPage = () => {
  return (
    <div>ThankYouPage</div>
  )
}

export default ThankYouPage