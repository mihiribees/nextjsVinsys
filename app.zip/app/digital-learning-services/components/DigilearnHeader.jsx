
export default function DigilearnHeader() {
  return (
    <div>DigilearnHeader</div>
  )
}
