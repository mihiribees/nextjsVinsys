import React from 'react'

const ElearningPlatform = () => {
  return (
    <div>ElearningPlatform</div>
  )
}

export default ElearningPlatform